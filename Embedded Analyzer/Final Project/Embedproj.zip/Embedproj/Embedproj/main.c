/*
 * Embedproj.c
 *
 * Created: 4/24/2018 3:57:34 PM
 * Author : gdrivas and cnwakama
 */ 

//  Sample code for using USART, WINAVR
//
//  Resource: A. Kruger, April 2010
//
//  Transmission is polled, but reception is interrupt driven.  In
//  applications that interact with a user via a RS232 link and a PC,
//  polled data transmission from controller to PC is not a limitation.
//
//  The code below assumes an AVR with USART  TX and RX pins on PD0 and
//  PD1 respectively.  For example, ATmega88PA.  Change usart_init to
//  match your processor.

//#ifndef UART_RX0_BUFFER_SIZE
//#define UART_RX0_BUFFER_SIZE 128 /**< Size of the circular receive buffer, must be power of 2 */
//#endif

#define F_CPU 8000000L        // This should match the processor speed
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>     //  Routine for FLASH (program memory)
#include <util/delay.h>
#include <string.h>
#include <stdio.h>
//#define BAUD_RATE 9600        // Baud rate. The usart_int routine
#define MAXLENGTH 8
#include "i2cmaster.h"
#define Dev24C02  0x58      // device address of EEPROM 24C02, see datasheet
#define  COMMAND 0x00
#include <math.h>
#define UART_RX_BUFFER_MASK ( RX_BUFFER_SIZE - 1)


// uses this and then sets 8N1

// Variables and #define for the RX ring buffer.

#define RX_BUFFER_SIZE 64
unsigned char rx_buffer[RX_BUFFER_SIZE];
volatile unsigned char rx_buffer_head;
volatile unsigned char rx_buffer_tail;



// Function prototypes.
unsigned char uart_buffer_empty(void);
void usart_prints(const char *ptr);
void usart_printf(const char *ptr);


void usart_putc(const char c); //look at size
void adc_init();
uint16_t adc_read(uint8_t ch);
void usart_init(void);
unsigned char usart_getc(void);

int uart_available(void);
const int size = 1250;
static float voltageSamples[size];
/*--------------------------------------------
void checkCommand();
void getCommandLine(uint8_t line[MAXLENGTH], const char c); //look at command line
uint8_t setVoltage(uint8_t t[], uint8_t channel, float * v);

uint8_t setDelay(uint8_t h[], uint8_t start);
uint8_t validitor(uint8_t v[], uint8_t intValue[], const char c);
void sineWave(uint8_t freq, uint8_t channel, uint16_t numRev);
//static char q[25];

---------------------------------------------*/

int main(void)
{
	
	sei();// Enable interrupts
	
	adc_init();
	usart_init();
	//i2c_init();
	//sprintf(q,"\n\r");
	
	
	/*char ho[25]; 
	sprintf(ho, "Hello World\n\r");
	usart_prints(ho);*/
	
	
	while (1){
		//checkCommand();
	}
	
	
	return(1);
}
void getSamples(const int rate, float voltageSamples[size]){
	uint8_t ch = 0;
	uint8_t intsize = (uint8_t) round((1/(2*rate)/1250) * 1000000);
	for (uint8_t i = 0; i< size; i++){
		voltageSamples[i] = adc_read(ch);
		voltageSamples[i] = voltageSamples[i] * 5/1024;
		//uint8_t val = i*time;
		
		///sprintf(str, "\n\rt=%d s, v=%f V",val,achf);
		//usart_prints(str);
		//delaying
		for (int j = 0; j<intsize; j++)
			_delay_us(1);
	}
}



ISR(USART_RX_vect)
{
	// UART receive interrupt handler.
	// To do: check and warn if buffer overflows.
	
	char c = UDR0;
	rx_buffer[rx_buffer_head] = c;
	if (rx_buffer_head == RX_BUFFER_SIZE - 1)
	rx_buffer_head = 0;
	else
	rx_buffer_head++;
}








